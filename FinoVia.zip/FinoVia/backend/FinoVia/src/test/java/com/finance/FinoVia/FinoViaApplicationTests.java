package com.finance.FinoVia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinoViaApplicationTests {

	@Test
	void contextLoads() {
	}

}

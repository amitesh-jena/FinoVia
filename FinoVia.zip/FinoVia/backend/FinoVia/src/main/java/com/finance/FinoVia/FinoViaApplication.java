package com.finance.FinoVia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinoViaApplication {

	public static void main(String[] args) {
		//SpringApplication.run(FinoViaApplication.class, args);
		System.out.println("hello");


	}

}

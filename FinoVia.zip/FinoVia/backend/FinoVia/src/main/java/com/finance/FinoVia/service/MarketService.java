package com.finance.FinoVia.service;

public class MarketService {
}

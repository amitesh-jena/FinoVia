package com.finance.FinoVia.model;

public class StockQuote {

}
